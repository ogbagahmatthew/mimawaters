  
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Notification: Someone just sent a order</title>
    </head>
    <body>
        <p>Hi, someone just sent an order.</p>
        <p>{{$name}}</p>
        <p>{{$quantity}}</p>
        <p>{{$email}}</p>
        <p>{{$phone_no}}</p>
        <p>{{$address}}</p>

    
    </body>
</html>