@extends('layouts.master')




@section('title')

Dashboard Mima Water

@endsection('title')


@section('content')

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Simple Table</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                        Name
                        <a href="service">
                      </th>
                      <th>
                        Country
                      </th>
                      <th>
                        City
                      </th>
                      <th class="text-right">
                        Salary
                      </th>
                    </thead>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

@endsection('content')

@section('scripts')
@endextends