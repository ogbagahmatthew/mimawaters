  
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Notification: Someone just sent a message</title>
    </head>
    <body>
        <p>Hi, someone just sent a message.</p>
        <p>{{$firstname}}</p>
        <p>{{$lastname}}</p>
        <p>{{$email}}</p>
        <p>{{$title}}</p>

    
    </body>
</html>