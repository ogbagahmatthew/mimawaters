
<div class="container">
    <div class="card">
        <div class="card-header">Menu</div>
        <div class="card-body">
                   @include('include.sidemenu3')
                </div>
               

            </div>
        </div>
        <style>
          body{
                
            }
            .card-body{
                /* position: absolute; */
                padding-left: 40%;
            }
         </style>