@extends('layouts.master')




@section('title')

Dashboard Mima Water

@endsection('title')


@section('content')

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Register Table</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>
                        Firstname
                      </th>
                      <th>
                        Lastname
                      </th>
                      <th>
                        Email
                      </th>
                      <th>
                        User Type
                      </th>
                      <th>
                        Edit
                      </th>
                      <th>
                        Delete
                      </th>
                      <th class="text-right">
                        Salary
                      </th>
                    </thead>
                    <tbody>
                    <tr>
                    <td>name</td>
                    <td>888</td>
                    <td>matthew
                                    </div>
              </div>
            </div>
          </div>
        </div>
      </div>

@endsection('content')

@section('scripts')
@endextends