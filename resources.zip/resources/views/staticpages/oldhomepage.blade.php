<!doctype html>

<html lang="en">
<head>
<link href="{{ asset('css/style/style.css')}}" rel="stylesheet">
</head>
<body>
</body>
<header>
    <div class='container'>
    <div>
        <img src="images/mima logo.jpg" alt=""  class="logoimg">
        <h1 class="ovo" >CLEAN WATER IS LIFE</h1>
        <nav class="nav-area">
            <ul>
                
                <h1><a href="{{url('about')}}"><button class="ogonla"> OUR PRODUCT PREVENT TYPHOID</button></a></h1>
            </ul>
        </nav>
    </div>
</div>
</header>
<section>
    <div class="showcase">
        
    </div>
</section>
 <body>
    <div id="home" class="hero-area">

        <!-- Backgound Image -->
        <div><img class='samson' src='/images/onovo.png'/>
            <h1 class="ovo" >CLEAN WATER IS LIFE</h1><br>
                <h2 class="ovo2">"Most families struggles with their<br>
                     health on a daily basis as a <br>
                     result of diseases associated with WATER"</h2>
                     {{-- <div><img class='mson' src='/images/yo.jpg'/></div> --}}

            {{-- <div><img class='yoma' src='/images/mima.jpg'></div> --}}
            {{-- <div><img class='yoma2' src='/images/mimaw.jpg'></div> --}}
        </div>
        {{-- <div><img class='yoma3' src='/images/waters.jpg'></div> --}}
        <!-- /Backgound Image -->
<footer>
        <div class="footer"></div>
    <a href="{{url('contact')}}" class="button">Contact</a>
     <a href="{{url('services')}}"class="button1">Services</a>
     <a href="{{url('about')}}" class="button2">About</a>
     <a href="{{url('homepage')}}" class="button3">Home</a>
</footer>
 </body>